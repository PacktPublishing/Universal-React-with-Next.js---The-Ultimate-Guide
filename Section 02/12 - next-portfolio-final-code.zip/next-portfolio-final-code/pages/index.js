import Layout from "../components/Layout";

const Index = () => (
  <Layout title="Home">
    <p>Welcome to the home page</p>
  </Layout>
);

export default Index;
