// import Button from "@material-ui/core/Button";

const FollowUser = () => {
  return <div>FollowUser</div>;
};

export default FollowUser;
