// import AppBar from "@material-ui/core/AppBar";
// import Typography from "@material-ui/core/Typography";
// import Tabs from "@material-ui/core/Tabs";
// import Tab from "@material-ui/core/Tab";

class ProfileTabs extends React.Component {
  state = {};

  render() {
    return <div>ProfileTabs</div>;
  }
}

export default ProfileTabs;
